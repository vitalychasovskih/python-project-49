#!/usr/bin/env python3
from brain_games.games.calc import calculation


def main():
    calculation()


if __name__ == '__main__':
    main()
