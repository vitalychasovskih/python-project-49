#!/usr/bin/env python3
from brain_games.even import is_number_even


def main():
    is_number_even()


if __name__ == '__main__':
    main()
