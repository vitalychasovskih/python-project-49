### Hexlet tests and linter status:
[![Actions Status](https://github.com/vitalychasovskih/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/vitalychasovskih/python-project-49/actions)
[![asciicast](https://asciinema.org/a/3M37qlt8OZwdjg3zJTIM4onQV.svg)](https://asciinema.org/a/3M37qlt8OZwdjg3zJTIM4onQV)