### Hexlet tests and linter status:
[![Actions Status](https://github.com/vitalychasovskih/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/vitalychasovskih/python-project-49/actions)
[![asciicast](https://asciinema.org/a/Y4zLAXZoNWHYUss7Tt1Ks9MNo.svg)](https://asciinema.org/a/Y4zLAXZoNWHYUss7Tt1Ks9MNo)
[![asciicast](https://asciinema.org/a/649145.svg)](https://asciinema.org/a/649145)